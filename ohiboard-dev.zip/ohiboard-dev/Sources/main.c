#include <stdio.h>

#include "derivative.h" /* include peripheral declarations */
#include "libohiboard.h"

int main(void)
{
	int counter = 0;

	testLibrary();
	printf("Hello World from OHIBoard! \n\r");
	
	for(;;) {	   
	   	counter++;
	}
	
	return 0;
}
